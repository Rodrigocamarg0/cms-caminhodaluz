-- Estrutura para tabela "escolaridade"
CREATE TABLE escolaridade (
  idescolaridade SERIAL PRIMARY KEY,
  escolaridade_name VARCHAR(255) NOT NULL
);

-- Inserção de dados na tabela "escolaridade"
INSERT INTO escolaridade (idescolaridade, escolaridade_name) VALUES
(1, 'Ensino Fundamental'),
(2, 'Ensino Médio'),
(3, 'Ensino Superior'),
(4, 'Pós-Graduação'),
(5, 'Mestrado'),
(6, 'Doutorado');