
-- Índices para tabelas

-- Índices de tabela `cargo`
ALTER TABLE cargo ADD PRIMARY KEY (cargo_id);

-- Índices de tabela `clubeLivro`
ALTER TABLE clube_livro ADD PRIMARY KEY (clube_livro_id);

-- Índices de tabela `clubeLivroRetirada`
ALTER TABLE clube_livro_retirada ADD PRIMARY KEY (clube_livro_retirada_id);

-- Índices de tabela `escolaridade`
ALTER TABLE escolaridade ADD PRIMARY KEY (escolaridade_id);

-- Índices de tabela `grupoEstudo`
ALTER TABLE grupo_estudo ADD PRIMARY KEY (grupo_estudo_id);

-- Índices de tabela `livraria`
-- (ignorado por ser uma tabela nova)

-- Índices de tabela `livrariaVenda`
-- (ignorado por ser uma tabela nova)

-- Índices de tabela `livro`
-- (ignorado por ser uma tabela nova)

-- Índices de tabela `nivel`
-- (ignorado por ser uma tabela nova)

-- Índices de tabela `pagamento`
ALTER TABLE pagamento ADD PRIMARY KEY (pagamento_id);
CREATE INDEX pagamento_pessoa_id_idx ON pagamento (pessoa_id);

-- Índices de tabela `pessoa`
ALTER TABLE pessoa ADD PRIMARY KEY (pessoa_id);

-- Índices de tabela `pessoaCargo`
ALTER TABLE pessoa_cargo ADD PRIMARY KEY (pessoa_cargo_id);

-- Índices de tabela `pessoaGrupoEstudo`
ALTER TABLE pessoa_grupo_estudo ADD PRIMARY KEY (pessoa_grupo_estudo_id);

-- Índices de tabela `pessoaLivro`
-- (ignorado por ser uma tabela nova)

-- Índices de tabela `profissao`
ALTER TABLE profissao ADD PRIMARY KEY (profissao_id);

-- Índices de tabela `recibo`
ALTER TABLE recibo ADD PRIMARY KEY (recibo_id);

-- Índices de tabela `tipo`
-- (ignorado por ser uma tabela nova)

-- Índices de tabela `usuario`
ALTER TABLE usuario ADD PRIMARY KEY (usuario_id);



-- AUTO_INCREMENT de tabela `cargo`
SELECT setval('cargo_idcargo_seq', 18);

-- AUTO_INCREMENT de tabela `clubeLivro`
SELECT setval('clubelivro_idclubeLivro_seq', 17);

-- AUTO_INCREMENT de tabela `clubeLivroRetirada`
SELECT setval('clubelivroretirada_idclubeLivroRetirada_seq', 317);

-- AUTO_INCREMENT de tabela `escolaridade`
SELECT setval('escolaridade_idescolaridade_seq', 3);

-- AUTO_INCREMENT de tabela `grupoEstudo`
SELECT setval('grupoestudo_idgrupoEstudo_seq', 145);

-- AUTO_INCREMENT de tabela `livraria`
SELECT setval('livraria_idlivraria_seq', 701);

-- AUTO_INCREMENT de tabela `livrariaVenda`
SELECT setval('livrariavenda_idlivrariaVenda_seq', 13);

-- AUTO_INCREMENT de tabela `livro`
SELECT setval('livro_idlivro_seq', 2178);

-- AUTO_INCREMENT de tabela `nivel`
SELECT setval('nivel_idnivel_seq', 21);

-- AUTO_INCREMENT de tabela `pagamento`
SELECT setval('pagamento_idpagamento_seq', 64491);

-- AUTO_INCREMENT de tabela `pessoa`
SELECT setval('pessoa_idpessoa_seq', 1041);

-- AUTO_INCREMENT de tabela `pessoaCargo`
SELECT setval('pessoacargo_idpessoaCargo_seq', 10);

-- AUTO_INCREMENT de tabela `pessoaGrupoEstudo`
SELECT setval('pessoagrupoestudo_idpessoaGrupoEstudo_seq', 2547);

-- AUTO_INCREMENT de tabela `pessoaLivro`
SELECT setval('pessoalivro_idpessoaLivro_seq', 1);

-- AUTO_INCREMENT de tabela `profissao`
SELECT setval('profissao_idprofissao_seq', 922);

-- AUTO_INCREMENT de tabela `recibo`
SELECT setval('recibo_idrecibo_seq', 6182);

-- AUTO_INCREMENT de tabela `tipo`
SELECT setval('tipo_idtipo_seq', 240);

-- AUTO_INCREMENT de tabela `usuario`
SELECT setval('usuario_idusuario_seq', 10);

COMMIT;
