-- Estrutura para tabela `nivel`
CREATE TABLE nivel (
  nivel_id SERIAL PRIMARY KEY,
  nivel_name VARCHAR(255) NOT NULL
);

-- Despejando dados para a tabela `nivel`
INSERT INTO nivel (nivel_id, nivel_name) VALUES
(1, 'G1'),
(2, 'G2'),
(3, 'G3'),
(4, 'G4'),
(5, 'G5'),
(6, 'G6'),
(7, 'G7'),
(8, 'G8'),
(9, 'G9'),
(10, 'G10'),
(11, 'G11'),
(12, 'G12'),
(13, 'G13'),
(14, 'G14'),
(15, 'G15'),
(16, 'G16'),
(17, 'G17'),
(18, 'G18'),
(19, 'G19'),
(20, 'G20'),
(21, 'GX');
