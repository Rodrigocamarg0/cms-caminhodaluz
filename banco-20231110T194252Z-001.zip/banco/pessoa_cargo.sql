-- Estrutura para tabela `pessoa_cargo`
CREATE TABLE pessoa_cargo (
  pessoa_cargo_id int NOT NULL PRIMARY KEY,
  pessoa_id int NOT NULL,
  cargo_id int NOT NULL,
  data_inicio date NOT NULL
);

-- Despejando dados para a tabela `pessoa_cargo`
INSERT INTO pessoa_cargo (pessoa_cargo_id, pessoa_id, cargo_id, data_inicio) VALUES
(1, 186, 2, '2015-01-01'),
(2, 186, 4, '2015-03-01'),
(4, 16, 6, '2015-01-01'),
(6, 11, 8, '0001-01-01'), -- PostgreSQL não suporta a data '0000-00-00'. Usando a menor data possível no PG.
(7, 3, 3, '2016-01-01'),
(8, 3, 7, '0001-01-01'), -- Mesma observação sobre a data.
(9, 186, 8, '0001-01-01'), -- Mesma observação sobre a data.
(10, 186, 16, '0001-01-01'); -- Mesma observação sobre a data.
