
-- Banco de dados do Software de Gestão para a Sociedade Espírita Caminho da Luz


-- Estrutura para tabela "cargo"
CREATE TABLE cargo (
  idcargo SERIAL PRIMARY KEY,
  cargo_name VARCHAR(255) NOT NULL
);




-- ================================================================
-- ========================= Data Dump ============================
-- ================================================================

-- Inserção de dados na tabela "cargo"
INSERT INTO cargo (idcargo, cargo_name) VALUES
(1, 'Secretaria'),
(2, 'Palestrante'),
(3, 'Diretoria'),
(4, 'Monitor'),
(5, 'Evangelizador'),
(6, 'Palestrante'),
(7, 'Dirigente espiritual'),
(8, 'Passes'),
(9, 'Trabalhador'),
(10, 'Estudante'),
(11, 'Evangelizando'),
(12, 'Acrescer desobsessão'),
(13, 'Irradiação'),
(14, 'Biblioteca'),
(15, 'Recreação'),
(16, 'Mediunica'),
(17, 'Recepção'),
(18, 'Livraria');
