CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  nome varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  senha varchar(255) NOT NULL,
  createdAt timestamp without time zone NOT NULL DEFAULT NOW(),
  updatedAt timestamp without time zone NOT NULL DEFAULT NOW()
);


-- Tabela roles
CREATE TABLE roles (
    role_id serial PRIMARY KEY,
    role_name varchar(255) UNIQUE NOT NULL
);

-- Tabela user_roles
CREATE TABLE user_roles (
    user_id int REFERENCES usuario(usuario_id),
    role_id int REFERENCES roles(role_id),
    PRIMARY KEY(user_id, role_id)
);

-- Tabela permissions
CREATE TABLE permissions (
    permission_id serial PRIMARY KEY,
    permission_name varchar(255) UNIQUE NOT NULL
);

-- Tabela role_permissions
CREATE TABLE role_permissions (
    role_id int REFERENCES roles(role_id),
    permission_id int REFERENCES permissions(permission_id),
    PRIMARY KEY(role_id, permission_id)
);

-- Despejando dados para a tabela `usuario`
INSERT INTO usuario (usuario_id, nome, email, senha) VALUES
(4, 'Alexandre', 'a.costa23@hotmail.com', '123456'),
(5, 'Ricardo', 'ricardo.kutscher@gmail.com', '123456'),
(6, 'Convidado', 'financeiro@gmail.com', '123456'),
(7, 'Fatima', 'feithme@bol.com.br', '123456'),
(8, 'Secretaria', 'secretaria@gmail.com', '123456'),
(9, 'Marcos', 'filo62@gmail.com', '123456'),
(10, 'Luis', 'luis.cristaldo@hotmail.com', '123456');
